project "sqlite3"
    kind "StaticLib"

    files { "sqlite3.c", "sqlite3.h" }
