#ifndef EVENT_HANDLER_H
#define EVENT_HANDLER_H

#include "config.h"
#include "game.h"
#include "client_card.h"

#endif //EVENT_HANDLER_H
