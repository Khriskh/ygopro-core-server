project "clzma"
    kind "StaticLib"
    files { "**.c", "**.h" }
